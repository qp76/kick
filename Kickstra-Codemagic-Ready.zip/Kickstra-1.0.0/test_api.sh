#!/bin/bash

# Kickstra API Test Script
# This script tests the Kick.com API endpoints used in the app

echo "🚀 Testing Kickstra API Endpoints"
echo "=================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test 1: Popular Streams API
echo -e "\n${YELLOW}1. Testing Popular Streams API${NC}"
echo "Endpoint: https://web.kick.com/api/v1/livestreams?limit=5&sort=viewer_count_desc"

response1=$(curl -s -w "\n%{http_code}" \
  -H "User-Agent: Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36" \
  -H "Accept: application/json" \
  -H "Origin: https://kick.com" \
  -H "Referer: https://kick.com/" \
  "https://web.kick.com/api/v1/livestreams?limit=5&sort=viewer_count_desc")
http_code1=$(echo "$response1" | tail -n1)
body1=$(echo "$response1" | sed '$d')

if [ "$http_code1" = "200" ]; then
    echo -e "${GREEN}✅ Popular Streams API: Success (HTTP $http_code1)${NC}"
    
    # Check if response has expected structure
    if echo "$body1" | jq -e '.data.livestreams' > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Response structure: Valid${NC}"
        stream_count=$(echo "$body1" | jq '.data.livestreams | length')
        echo "📊 Streams returned: $stream_count"
        
        # Show first stream info
        if [ "$stream_count" -gt 0 ]; then
            first_stream=$(echo "$body1" | jq -r '.data.livestreams[0]')
            title=$(echo "$first_stream" | jq -r '.title')
            viewers=$(echo "$first_stream" | jq -r '.viewer_count')
            channel=$(echo "$first_stream" | jq -r '.channel.username')
            echo "🎮 First stream: \"$title\" by $channel ($viewers viewers)"
        fi
        
        # Check pagination
        next_cursor=$(echo "$body1" | jq -r '.data.pagination.next_cursor')
        if [ "$next_cursor" != "null" ]; then
            echo -e "${GREEN}✅ Pagination: Next cursor available${NC}"
        else
            echo -e "${YELLOW}⚠️  Pagination: No next cursor${NC}"
        fi
    else
        echo -e "${RED}❌ Response structure: Invalid${NC}"
    fi
else
    echo -e "${RED}❌ Popular Streams API: Failed (HTTP $http_code1)${NC}"
fi

# Test 2: Channel Details API
echo -e "\n${YELLOW}2. Testing Channel Details API${NC}"
echo "Endpoint: https://kick.com/api/v2/channels/triel"

response2=$(curl -s -w "\n%{http_code}" \
  -H "User-Agent: Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36" \
  -H "Accept: application/json" \
  -H "Origin: https://kick.com" \
  -H "Referer: https://kick.com/" \
  "https://kick.com/api/v2/channels/triel")
http_code2=$(echo "$response2" | tail -n1)
body2=$(echo "$response2" | sed '$d')

if [ "$http_code2" = "200" ]; then
    echo -e "${GREEN}✅ Channel Details API: Success (HTTP $http_code2)${NC}"
    
    # Check if response has expected structure
    if echo "$body2" | jq -e '.slug' > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Response structure: Valid${NC}"
        username=$(echo "$body2" | jq -r '.user.username')
        followers=$(echo "$body2" | jq -r '.followers_count')
        verified=$(echo "$body2" | jq -r '.verified')
        echo "👤 Channel: $username ($followers followers, verified: $verified)"
        
        # Check if live
        is_live=$(echo "$body2" | jq -r '.livestream.is_live // false')
        if [ "$is_live" = "true" ]; then
            viewers=$(echo "$body2" | jq -r '.livestream.viewer_count')
            title=$(echo "$body2" | jq -r '.livestream.session_title')
            echo -e "${GREEN}🔴 Currently LIVE: \"$title\" ($viewers viewers)${NC}"
        else
            echo "⚫ Currently offline"
        fi
    else
        echo -e "${RED}❌ Response structure: Invalid${NC}"
    fi
else
    echo -e "${RED}❌ Channel Details API: Failed (HTTP $http_code2)${NC}"
fi

# Test 3: Chat History API (if channel is live)
if [ "$is_live" = "true" ]; then
    channel_id=$(echo "$body2" | jq -r '.id')
    echo -e "\n${YELLOW}3. Testing Chat History API${NC}"
    echo "Endpoint: https://web.kick.com/api/v1/chat/$channel_id/history"
    
    response3=$(curl -s -w "\n%{http_code}" \
      -H "User-Agent: Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36" \
      -H "Accept: application/json" \
      -H "Origin: https://kick.com" \
      -H "Referer: https://kick.com/" \
      "https://web.kick.com/api/v1/chat/$channel_id/history")
    http_code3=$(echo "$response3" | tail -n1)
    body3=$(echo "$response3" | sed '$d')
    
    if [ "$http_code3" = "200" ]; then
        echo -e "${GREEN}✅ Chat History API: Success (HTTP $http_code3)${NC}"
        
        if echo "$body3" | jq -e '.data.messages' > /dev/null 2>&1; then
            echo -e "${GREEN}✅ Response structure: Valid${NC}"
            message_count=$(echo "$body3" | jq '.data.messages | length')
            echo "💬 Messages returned: $message_count"
            
            if [ "$message_count" -gt 0 ]; then
                latest_message=$(echo "$body3" | jq -r '.data.messages[0]')
                sender=$(echo "$latest_message" | jq -r '.sender.username')
                content=$(echo "$latest_message" | jq -r '.content')
                echo "💬 Latest: $sender: \"$content\""
            fi
        else
            echo -e "${RED}❌ Response structure: Invalid${NC}"
        fi
    else
        echo -e "${RED}❌ Chat History API: Failed (HTTP $http_code3)${NC}"
    fi
else
    echo -e "\n${YELLOW}3. Skipping Chat History API (channel offline)${NC}"
fi

# Summary
echo -e "\n${YELLOW}📋 Test Summary${NC}"
echo "================"

if [ "$http_code1" = "200" ]; then
    echo -e "${GREEN}✅ Popular Streams API${NC}"
else
    echo -e "${RED}❌ Popular Streams API${NC}"
fi

if [ "$http_code2" = "200" ]; then
    echo -e "${GREEN}✅ Channel Details API${NC}"
else
    echo -e "${RED}❌ Channel Details API${NC}"
fi

if [ "$is_live" = "true" ]; then
    if [ "$http_code3" = "200" ]; then
        echo -e "${GREEN}✅ Chat History API${NC}"
    else
        echo -e "${RED}❌ Chat History API${NC}"
    fi
else
    echo -e "${YELLOW}⏭️  Chat History API (skipped)${NC}"
fi

echo -e "\n${GREEN}🎉 API testing complete!${NC}"
