# Test Scenarios for Kickstra App

## Manual Test Cases

### 1. Home Screen Tests

#### Test Case 1.1: Initial Load

- **Description**: Test popular streams loading on app start
- **Steps**:
  1. Launch the app
  2. Observe home screen
- **Expected Result**:
  - Loading indicator appears
  - Popular streams list loads
  - Each stream shows thumbnail, title, channel info, viewer count

#### Test Case 1.2: Infinite Scroll

- **Description**: Test pagination functionality
- **Steps**:
  1. Launch app and wait for streams to load
  2. Scroll to bottom of list
  3. Observe loading more indicator
- **Expected Result**:
  - More streams load automatically
  - Loading indicator appears at bottom
  - New streams append to existing list

#### Test Case 1.3: Error Handling

- **Description**: Test network error scenarios
- **Steps**:
  1. Disable network connection
  2. Launch app OR pull to refresh
- **Expected Result**:
  - Error message displays
  - Retry button appears
  - Retry button restores functionality when network restored

#### Test Case 1.4: Stream Item Click

- **Description**: Test navigation to player
- **Steps**:
  1. Tap on any stream item
- **Expected Result**:
  - Navigation to player screen (currently shows TODO)

### 2. API Integration Tests

#### Test Case 2.1: Popular Streams API

- **Endpoint**: `https://web.kick.com/api/v1/livestreams?limit=24&sort=viewer_count_desc`
- **Test**: Verify API response structure matches DTOs
- **Expected**: Valid JSON with livestreams array and pagination

#### Test Case 2.2: Pagination API

- **Endpoint**: Same as above with `&cursor=<next_cursor>` parameter
- **Test**: Verify cursor-based pagination works
- **Expected**: Different streams on subsequent pages

### 3. UI/UX Tests

#### Test Case 3.1: Material Design

- **Description**: Verify Material 3 theming
- **Expected**:
  - Kick brand colors (green #53FC18)
  - Proper dark/light theme support
  - Material 3 components

#### Test Case 3.2: Stream Item Display

- **Description**: Verify stream item components
- **Expected**:
  - Thumbnail image loads correctly
  - Live indicator shows in green
  - Viewer count displays correctly
  - Channel avatar and username visible
  - Stream title truncates properly
  - Tags display (max 3)

### 4. Performance Tests

#### Test Case 4.1: Image Loading

- **Description**: Test Coil image loading performance
- **Expected**:
  - Images load smoothly
  - Placeholder during loading
  - Error handling for failed images

#### Test Case 4.2: List Performance

- **Description**: Test LazyColumn performance with many items
- **Expected**:
  - Smooth scrolling
  - No memory leaks
  - Proper item recycling

## Automated Test Ideas

### Unit Tests

- ViewModel state management
- Use case logic
- Repository implementations
- DTO to domain model mapping

### Integration Tests

- API service calls
- Repository integration
- End-to-end data flow

### UI Tests

- Navigation flows
- Error state handling
- Loading state verification

## Test Data

### Sample API Responses

- Popular streams: Check `docs/popular.json`
- Channel details: Check `docs/channel.json`
- Chat history: Check `docs/chat.json`

## Known Issues/Limitations

1. Player screen not implemented yet
2. No offline functionality
3. No user authentication
4. Chat integration pending
5. PiP mode not implemented

## Next Testing Steps

1. Implement Player screen and test video playback
2. Add unit tests for ViewModels
3. Integration tests for API calls
4. UI tests for navigation flows
5. Performance testing with large datasets
